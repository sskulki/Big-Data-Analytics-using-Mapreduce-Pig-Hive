
sqoop import --connect jdbc:mysql://127.0.0.1/Test --username root --password 1234 --table NCHS_Cost_Data -m 1 --hive-import --create-hive-table --hive-table NCHS_Cost_Data_Hive

sqoop import --connect jdbc:mysql://127.0.0.1/Test --username root --password 1234 --table NCHS_DATA -m 1 --hive-import --create-hive-table --hive-table NCHS_DATA_Hive


INSERT OVERWRITE DIRECTORY  'hdfs://localhost:54310/pdafinal/HiveOutput' ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' select a.Year, SUM(a.Total_Costs), SUM(b.Observed_Deaths), SUM(Expected_Deaths) from NCHS_Cost_Data_Hive a JOIN (select year, Observed_Deaths, Expected_Deaths from NCHS_DATA_Hive) b on a.Year = b.Year group by a.Year;
